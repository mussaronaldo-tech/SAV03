<?php
$api_key = "51b6bef39bebe2a7d0227bd1b341b729";
$api_url = "https://peakerr.com/api/v2";
$paypal_email = "mussa_ronaldo@hotmail.es";
?>