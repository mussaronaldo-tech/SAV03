<?php
include("config.php");
?>
<!DOCTYPE html>
<html>
<head>
  <title>SAV03 🚀 | Venta de seguidores</title>
</head>
<body>
  <h1>Bienvenido a SAV03 🚀</h1>
  <p>Tu panel de venta de seguidores está activo.</p>
</body>
</html>
